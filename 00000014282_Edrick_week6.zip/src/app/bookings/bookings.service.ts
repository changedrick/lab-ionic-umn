import { Injectable } from '@angular/core';
import { Booking } from './bookings.model';

@Injectable({
  providedIn: 'root'
})
export class BookingsService {
  private booking : Booking[] = [
    {
      id: '1',
      placeId: 'P1',
      userId:'U1',
      placeTitle: 'Residence',
      guestNumber: 2
    },
    {
      id: '2',
      placeId: 'P2',
      userId:'U2',
      placeTitle: 'Newton',
      guestNumber: 9
    }
  ]
  constructor() { }

  getAllBooking(){
    return[...this.booking];
  }

  getBooking(bookingId: String){
    return {
      ...this.booking.find(booking => {
        return booking.id === bookingId;
      })
    };
  }

  deleteBooking(bookingId: String){
    this.booking = this.booking.filter(booking => {
      return booking.id != bookingId;
    });
  }

  removeBooking(bookingId: String){
    this.booking = this.booking.filter(booking => {
      console.log(booking.id);
      return booking.id != bookingId;
    });
  }

}
