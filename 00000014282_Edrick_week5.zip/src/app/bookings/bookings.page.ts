import { Component, OnInit } from '@angular/core';
import { Booking } from './bookings.model';
import { BookingsService } from './bookings.service';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.page.html',
  styleUrls: ['./bookings.page.scss'],
})
export class BookingsPage implements OnInit {

  booking: Booking[];

  constructor(private bookingSrvc: BookingsService) { }

  ngOnInit() {
    this.booking = this.bookingSrvc.getAllBooking();
  }

}
