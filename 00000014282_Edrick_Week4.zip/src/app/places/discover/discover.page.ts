import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { PlacesService } from '../places.service';
import { Place } from '../places.model';

@Component({
  selector: 'app-discover',
  templateUrl: './discover.page.html',
  styleUrls: ['./discover.page.scss'],
})
export class DiscoverPage implements OnInit {
  loadedPlaces: Place [];
  constructor(private menuCtrl: MenuController, private service: PlacesService) { }

  ngOnInit() {
    this.loadedPlaces = this.service.getAllPlaces();
  }

  onOpenMenu(){
    this.menuCtrl.toggle('m1');
  }

  ionViewWillLeave(){
    this.menuCtrl.close('m1');
  }

}
