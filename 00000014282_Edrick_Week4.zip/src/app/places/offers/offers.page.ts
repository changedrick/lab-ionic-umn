import { Component, OnInit } from '@angular/core';
import { Place } from '../places.model';
import { PlacesService } from '../places.service';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.page.html',
  styleUrls: ['./offers.page.scss'],
})
export class OffersPage implements OnInit {
  loadedPlaces: Place [];

  constructor(private service: PlacesService, private menuCtrl: MenuController) { }

  ngOnInit() {
    this.loadedPlaces = this.service.getAllPlaces();
  }

  onOpenMenu(){
    this.menuCtrl.toggle('m1');
  }
  
  ionViewWillLeave(){
    this.menuCtrl.close('m1');
  }
}
