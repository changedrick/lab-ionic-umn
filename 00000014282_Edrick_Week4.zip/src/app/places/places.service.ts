import { Injectable } from '@angular/core';
import { Place } from './places.model';

@Injectable({
  providedIn: 'root'
})
export class PlacesService {
    private places : Place[] = [
        new Place(
            'p1',
            'Serpong M-Town',
            '2BR apartment near Summarecon Mal Serpong',
            'https://serpongku.com/wp-content/uploads/2017/11/sms-mall-di-serpong.jpg',
            70000000
        ),
        new Place(
            'p2',
            'Scientia Residence',
            'Near UMN with many choices of foods around',
            'https://img.rea-asia.com/rumah123/250x250-crop/apartment/ap18/1892427/original/aps1892427-apartemen-di-jual-di-gading-serpong-scientia-garden-tangerang-15575955063293.jpg',
            1000000000
        )
    ]
    constructor() { }

    getAllPlaces(){
        return[...this.places];
    }
}
