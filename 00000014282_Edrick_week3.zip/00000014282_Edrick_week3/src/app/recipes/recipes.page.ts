import { Component, OnInit } from '@angular/core';
import { Recipe } from './recipe.model';
import { RecipesService } from './recipes.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.page.html',
  styleUrls: ['./recipes.page.scss'],
})
export class RecipesPage implements OnInit {

  recipes: Recipe[];

  constructor(private recipesService: RecipesService, private toastController: ToastController) { }

  ngOnInit() {  
    this.recipes = this.recipesService.getAllRecipes();
  }

  ionViewWillEnter(){
    this.recipes = this.recipesService.getAllRecipes();
  }

  // getDetail(id:any){  
  //   console.log(this.recipesService.getRecipe(id));
  // }

  removeRecipe(id: String){
    this.recipesService.deleteRecipe(id);
  }

}
