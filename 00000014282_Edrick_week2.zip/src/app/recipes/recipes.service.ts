import { Injectable } from '@angular/core';
import { Recipe } from './recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {
  private recipes : Recipe[] = [
    {
      id: 'r1',
      title: 'Gado-gado',
      imageUrl: 'https://i1.wp.com/resepkoki.id/wp-content/uploads/2016/12/Resep-Gado-Gado.jpg?fit=2461%2C2359&ssl=1',
      ingredients: ['Lontong', 'Sawi', 'Bumbu kecap', 'Tauge']
    },
    {
      id: 'r2',
      title: 'Nasi Goreng',
      imageUrl: 'https://i1.wp.com/resepkoki.id/wp-content/uploads/2016/12/Resep-Gado-Gado.jpg?fit=2461%2C2359&ssl=1',
      ingredients: ['Lontong', 'Sawi', 'Bumbu kecap', 'Tauge']
    }
  ]

  constructor() { }

  getAllRecipes(){
    return[...this.recipes];
  }

  getRecipe(recipeId: String){
    return {
      ...this.recipes.find(recipe => {
        return recipe.id === recipeId;
      })
    };
  }

  deleteRecipe(recipeId: String){
    var temp;
    this.recipes.forEach((recipe, i) => {
      if(recipe.id === recipeId){
        temp = i;
      }
    })
    this.recipes.splice(temp);
  }
}
