
function asd(){
    var nama = document.getElementById("nama").value;
    var jumlah = document.getElementById("nama").value;

    console.log(nama);
}